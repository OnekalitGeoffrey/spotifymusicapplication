package onekalit.gu.ac.ug.sportifymusicapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class SpotifyWebActivity : AppCompatActivity() {
    private val web: WebView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spotify_web)

        val spotifyweb: WebView = findViewById<WebView>(R.id.website)
        spotifyweb?.webViewClient = WebViewClient()
        spotifyweb?.loadUrl("https://spotify.com")
        val webSettings: WebSettings? = spotifyweb?.settings
        webSettings?.javaScriptEnabled = true
    }

    override fun onBackPressed() {
        if (web!!.canGoBack()) {
            web.goBack()
        } else {
            super.onBackPressed()
        }
    }
}