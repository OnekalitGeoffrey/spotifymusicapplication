package onekalit.gu.ac.ug.sportifymusicapplication;

import android.app.Activity;

public class webview extends Activity {
}
