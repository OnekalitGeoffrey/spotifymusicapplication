package onekalit.gu.ac.ug.sportifymusicapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class SplashActivity : AppCompatActivity() {
    private val SPLASHTIME = 4000L
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Handler().postDelayed({
            val screen = Intent(this,SpotifyWebActivity::class.java)
            startActivity(screen)
            finish()
        },SPLASHTIME)
    }
}